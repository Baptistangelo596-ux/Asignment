"""
evaluation.py - small helpers that check answers against the expected results in tests.csv.

The automatic check is only a first pass. An answer really passes when it is correct,
the cited evidence supports it, and it follows the intended policy version, so read
every answer yourself and use the 'manual_review' column in test_results.csv.
"""
import re

REFUSAL_PHRASE = "could not find enough information in the provided documents"


def norm(text):
    """Lower-case and make formatting differences harmless.

    30,000 -> 30000, LaTeX 12{,}200 -> 12200, '60 %' -> '60%', special hyphens -> '-'.
    """
    text = str(text).lower()
    text = text.replace("{,}", ",")
    text = re.sub(r"[\u2010\u2011\u2012\u2013\u2014\u2015\u2212]", "-", text)
    text = re.sub(r"[\u00a0\u202f]", " ", text)
    text = re.sub(r"(?<=\d),(?=\d)", "", text)
    text = re.sub(r"\s+%", "%", text)
    text = text.replace("**", "").replace("\\", "")
    return re.sub(r"\s+", " ", text).strip()


def split_list(value):
    """'a; b' -> ['a', 'b'] (empty string -> [])."""
    return [part.strip() for part in str(value or "").split(";") if part.strip()]


def terms_present(text, spec):
    """Check a spec such as '14; 7 calendar days|7 days'.

    ';' separates items that must ALL appear; '|' separates alternatives for one item.
    Returns (all_found, [items that were missing]).
    """
    haystack = norm(text)
    missing = []
    for item in split_list(spec):
        alternatives = [norm(a) for a in item.split("|") if a.strip()]
        if not any(alt in haystack for alt in alternatives):
            missing.append(item)
    return (not missing), missing


def forbidden_hits(text, spec):
    """Return the forbidden phrases (from a ';'/'|' spec) that appear in the text."""
    haystack = norm(text)
    hits = []
    for item in split_list(spec):
        for alt in item.split("|"):
            if alt.strip() and norm(alt) in haystack:
                hits.append(alt.strip())
    return hits


def grade(test, answer, cited, retrieved, error=None):
    """Automatic first-pass grade. Returns ('PASS' | 'FAIL', reason)."""
    if error:
        return "FAIL", f"No usable answer ({error})."
    answer = answer or ""
    problems = []

    if test["category"] == "Missing answer":
        if REFUSAL_PHRASE not in norm(answer):
            problems.append("did not say that the information could not be found")
    else:
        ok, missing = terms_present(answer, test.get("must_include", ""))
        if not ok:
            problems.append("answer lacks expected content: " + ", ".join(missing))

    hits = forbidden_hits(answer, test.get("must_not_include", ""))
    if hits:
        problems.append("answer contains forbidden text (wrong policy version or obeyed an injected "
                        "instruction): " + ", ".join(hits))

    expected_sources = split_list(test.get("expected_sources", ""))
    not_cited = [s for s in expected_sources if s not in cited]
    if not_cited:
        note = "not cited"
        if any(s not in retrieved for s in not_cited):
            note = "not cited and not retrieved"
        problems.append(f"expected source(s) {note}: " + ", ".join(not_cited))

    bad_sources = [s for s in split_list(test.get("forbidden_sources", "")) if s in cited]
    if bad_sources:
        problems.append("cited a source that must not be used: " + ", ".join(bad_sources))

    if problems:
        return "FAIL", "; ".join(problems)
    if test["category"] == "Missing answer":
        return "PASS", "Correctly said the information is not in the documents."
    cited_text = ", ".join(cited) if cited else "no citation required"
    return "PASS", f"Expected facts present; cites {cited_text}; no forbidden text."
