"""
app.py - Streamlit interface for the Glossip Beauty knowledge assistant.

Run:  python -m streamlit run app.py
"""
import streamlit as st

from ingest import DOCS_DIR, build_index, index_status, read_manifest
from rag import NO_INFO, ask_rag, open_index

st.set_page_config(page_title="Glossip Beauty Assistant", page_icon="💅", layout="wide")

MODE_TEXT = {
    "current": "Current policy (version in force today)",
    "archived": "Archived policy (old rules, because you asked about them)",
    "compare": "Comparison of the current and the archived policy",
}
EXAMPLES = [
    "What time does the last appointment start from Tuesday to Saturday?",
    "I want a hair botox. How much is it and how much deposit do I need to pay?",
    "How much notice was needed to cancel under the previous policy, and how much is needed now?",
    "Is there parking at the salon?",
    "When is the free skin consultation day and where is it held?",
]


@st.cache_resource(show_spinner="Loading the embedding model and the index (first run can take a minute)...")
def get_vector_db():
    return open_index()


def rebuild_index():
    with st.spinner("Re-reading the documents, re-chunking and re-embedding..."):
        build_index()
    st.cache_resource.clear()      # forget the old, cached index


def use_example(text):
    st.session_state["question"] = text


# ---------------------------------------------------------------- header
st.title("💅 Glossip Beauty Assistant")
st.write(
    "**Glossip Beauty** is a fictional women-only beauty salon in Karachi. This assistant answers questions about "
    "services, prices, opening hours, client policy and front-desk procedures. The front-desk team and booking "
    "staff can use it. It answers only from the company documents and shows the evidence for every answer."
)

# ---------------------------------------------------------------- index status
status = index_status()
if status == "missing":
    rebuild_index()
    status = "fresh"
elif status == "stale":
    st.warning(
        "The documents in the docs folder have changed since the index was built. "
        "Answers still come from the OLD index. Click **Rebuild index** in the sidebar to update it."
    )

# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("Settings")
    k = st.slider("Chunks to retrieve (k)", min_value=1, max_value=5, value=3)
    st.header("Knowledge base")
    manifest = read_manifest()
    if manifest:
        st.caption(f"{manifest['documents']} documents, {manifest['chunks']} chunks "
                   f"(chunk size {manifest['chunk_size']}, overlap {manifest['chunk_overlap']}). "
                   f"Built {manifest['built_at']}.")
    if st.button("Rebuild index"):
        rebuild_index()
        st.success("Index rebuilt from the current documents.")
        st.rerun()
    st.header("Try an example")
    for number, example in enumerate(EXAMPLES):
        st.button(example, key=f"example_{number}", on_click=use_example, args=(example,))
    st.caption("Classroom prototype with fictional data. Not for real users.")

# ---------------------------------------------------------------- question form
with st.form("ask_form"):
    question = st.text_input("Your question", key="question",
                             placeholder="For example: How much is a keratin treatment?")
    submitted = st.form_submit_button("Ask")

if submitted:
    if not question.strip():
        st.warning("Please type a question before pressing Ask.")
    else:
        with st.spinner("Searching the documents and writing the answer..."):
            result = ask_rag(question, k=k, vector_db=get_vector_db())

        st.caption("Policy mode used for retrieval: " + MODE_TEXT[result["mode"]])
        st.subheader("Answer")
        if result["error"]:
            st.error(result["answer"])
        elif NO_INFO.lower().rstrip(".") in result["answer"].lower():
            st.info(result["answer"])
        else:
            st.success(result["answer"])

        if result["sources"]:
            st.subheader("Sources")
            for s in result["sources"]:
                cited = "cited in the answer" if s["source"] in result["cited"] else "retrieved, not cited"
                st.markdown(f"**{s['number']}. `{s['source']}`**: version {s['version']}, "
                            f"status {s['status']} ({cited})")
                excerpt = s["text"].replace("\n", " ")
                st.caption(excerpt[:240] + ("..." if len(excerpt) > 240 else ""))

            st.subheader("Retrieved chunks")
            for s in result["sources"]:
                with st.expander(f"Chunk {s['number']}: {s['source']} (v{s['version']}, {s['status']})"):
                    st.text(s["text"])
                    st.caption(f"Distance: {s['distance']:.3f} (lower means closer to the question)")

st.divider()
st.caption(f"Documents are read from: {DOCS_DIR.name}/ . Answers can be wrong: always check the sources above.")
