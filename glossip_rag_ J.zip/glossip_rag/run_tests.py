"""
run_tests.py - run all 20 questions from tests.csv through the real pipeline.

tests.csv holds the questions, expected answers and expected source documents.
They were written BEFORE the final run (assignment step 6). Nothing in rag.py or
app.py knows these answers: the answers always come from retrieval + the LLM.

Usage:
    python run_tests.py                 # k = 3, writes test_results.csv
    python run_tests.py --k 5 --delay 3
"""
import argparse
import time

import pandas as pd

from evaluation import grade, split_list
from ingest import BASE_DIR, build_index, index_status
from rag import ask_rag, open_index

TESTS_FILE = BASE_DIR / "tests.csv"
RESULTS_FILE = BASE_DIR / "test_results.csv"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--k", type=int, default=3, help="chunks to retrieve (default 3)")
    parser.add_argument("--delay", type=float, default=2.0, help="seconds between LLM calls (free-tier limits)")
    args = parser.parse_args()

    status = index_status()
    if status != "fresh":
        print(f"Index is {status}: rebuilding it from docs/ first ...")
        build_index()
    vector_db = open_index()

    tests = pd.read_csv(TESTS_FILE, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    rows = []
    for _, test in tests.iterrows():
        test = test.to_dict()
        result = ask_rag(test["question"], k=args.k, vector_db=vector_db)
        retrieved = [s["source"] for s in result["sources"]]
        verdict, reason = grade(test, result["answer"], result["cited"], retrieved, result["error"])
        rows.append({
            "id": test["id"],
            "category": test["category"],
            "question": test["question"],
            "expected_answer": test["expected_answer"],
            "expected_sources": test["expected_sources"] or "(none - should refuse)",
            "actual_answer": result["answer"],
            "actual_cited_sources": "; ".join(result["cited"]) or "(none)",
            "retrieved_sources": "; ".join(dict.fromkeys(retrieved)),
            "policy_mode": result["mode"],
            "result": verdict,
            "reason": reason,
            "manual_review": "",     # <- read each answer yourself and write OK / CHANGE TO FAIL here
        })
        print(f"[{test['id']:>2}] {verdict}  {test['category']:<16} {reason[:90]}")
        time.sleep(args.delay)

    table = pd.DataFrame(rows)
    table.to_csv(RESULTS_FILE, index=False, encoding="utf-8-sig")   # utf-8-sig so Excel opens it correctly
    print("\nPASS by category (automatic check):")
    print(table.groupby("category")["result"].apply(lambda s: f"{(s == 'PASS').sum()}/{len(s)}").to_string())
    print(f"\nTotal: {(table['result'] == 'PASS').sum()}/{len(table)} passed.")
    print(f"Saved {RESULTS_FILE.name}. Now read every answer and fill in the manual_review column.")


if __name__ == "__main__":
    main()
