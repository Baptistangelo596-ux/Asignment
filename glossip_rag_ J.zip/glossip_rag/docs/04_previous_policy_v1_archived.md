# Glossip Beauty - Client Policy (ARCHIVED)

Policy version: 1.0
Effective date: 1 January 2025
End date: 31 August 2026
Status: ARCHIVED (no longer in force)
Replaced by: Policy version 2.0, effective 1 September 2026

This version is kept for reference only. Do not use it for bookings made on or after 1 September 2026.

## 1. Booking
- Appointments were made by phone, WhatsApp, or Instagram direct message.
- For hair colour, keratin, and hair botox, clients had to book at least 24 hours in advance.

## 2. Deposit
A deposit of 20% was required for any single service priced above PKR 10,000. Services at or below PKR 10,000 needed no deposit.

## 3. Cancellation and Rescheduling
- Clients had to give at least 12 hours' notice to cancel or reschedule.
- If notice was shorter than 12 hours, the deposit was not refunded.
- If no deposit was paid, there was no late cancellation fee.
- A client could reschedule twice for free.

## 4. Late Arrival
- We held an appointment for 20 minutes after the booked time.
- After 20 minutes, the booking was cancelled.

## 5. Happy Hours Discount
- Happy Hours ran Tuesday to Saturday, 11:30 AM to 2:00 PM.
- The discount was 15% on all services.
- Walk-ins were allowed during Happy Hours if a chair was free.

## 6. Refunds
- Cash refunds were not given for completed services.
- Free corrections were offered within 3 days.

## 7. Exceptions
**Exception A: Bridal bookings.** Bridal bookings needed a 50% deposit and 5 days' notice to cancel.

## 8. Privacy
We did not take photos of clients without permission.
