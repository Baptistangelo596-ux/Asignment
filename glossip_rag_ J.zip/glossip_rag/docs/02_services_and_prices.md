# Glossip Beauty - Services and Prices

Document type: Services and prices
Prices are in Pakistani Rupees (PKR). Effective: 1 September 2026. Status: CURRENT
Hair prices are for shoulder-length hair. Long hair may cost more, and the final price is confirmed at booking.

## Hair Care and Styling
| Service | Price (PKR) | Duration |
|---|---|---|
| Haircut (soft layers or trim) | 2,500 | 60 minutes |
| Blow-dry | 1,800 | 45 minutes |
| Beach waves styling | 2,200 | 50 minutes |
| Highlights | 12,000 | 3 hours |
| Balayage | 18,000 | 4 hours |

## Luxury Hair Treatments
| Service | Price (PKR) | Duration |
|---|---|---|
| Olaplex treatment | 6,000 | 60 minutes |
| Hair botox | 14,000 | 2.5 hours |
| Keratin treatment | 16,000 | 3 hours |

Keratin and hair botox treatments need a patch test if the client has had colour or chemical treatment in the last 30 days.

## Nail Care
| Service | Price (PKR) | Duration |
|---|---|---|
| Classic manicure | 1,800 | 45 minutes |
| Classic pedicure | 2,500 | 60 minutes |
| Gel nails | 3,500 | 75 minutes |
| Gel extensions | 5,500 | 105 minutes |

## Facials and Skincare
| Service | Price (PKR) | Duration |
|---|---|---|
| Hydra peeling facial | 6,500 | 60 minutes |
| Hydrating mask facial | 4,500 | 50 minutes |

## Face Hair Removal
| Area | Threading (PKR) | Waxing (PKR) |
|---|---|---|
| Eyebrows | 300 | 350 |
| Upper lip | 300 | 350 |
| Chin | 300 | 350 |
| Cheeks | 450 | 600 |
| Full face | 2,000 | 3,000 |

## Body Hair Removal (Waxing)
| Area | Price (PKR) |
|---|---|
| Underarms | 800 |
| Half arms | 1,000 |
| Full arms | 1,600 |
| Half legs | 1,500 |
| Full legs | 2,000 |
| Full body | 10,000 |

## Massage
| Service | Price (PKR) | Duration |
|---|---|---|
| Relaxing massage | 5,000 | 60 minutes |

## Bridal and Event Packages
We offer a Shaadi Season Refresh Package, which combines a blow-dry, a hydra peeling facial, and a classic manicure for PKR 9,500. Packages are not eligible for the Happy Hours discount.

## Notes
- Prices include all taxes.
- Our team does not offer eyelash extensions.
