# Glossip Beauty - Company Overview

Document type: Company overview
Last updated: 1 September 2026

## About Us
Glossip Beauty is a women-only beauty salon and wellness studio in Karachi, Pakistan. We opened in March 2023 and serve women who want quality hair, nail, skin, and grooming services in a private and comfortable setting. Glossip Beauty is a fictional business created for a classroom project. Its address, contact details, prices, and policies are invented and are not those of any real salon.

We do not offer any services for men. This is a permanent rule of the salon.

## What We Offer
Our services fall into six groups:
- Hair care and styling (cuts, blow-dries, colour)
- Luxury hair treatments (keratin, hair botox, Olaplex)
- Nail care (manicure, pedicure, gel nails)
- Facials and skincare
- Face and body hair removal (threading and waxing)
- Massage

Full prices and durations are listed in the Services and Prices document.

## Location
Suite 204, 2nd Floor, Al-Noor Plaza, Khayaban-e-Shamsheer, DHA Phase 5, Karachi, Pakistan.

## Contact and Booking
- Phone and WhatsApp: 0300 1234567
- Instagram: @glossipbeauty_demo
- Email: hello@glossipbeauty.example

Appointments are taken only by phone, WhatsApp, or Instagram direct message. We do not accept email bookings. Walk-ins are not accepted during Happy Hours.

## Opening Hours
- Tuesday to Saturday: 11:30 AM to 8:00 PM
- Sunday: 12:30 PM to 8:30 PM
- Monday: Closed

The last appointment of the day must start at least 90 minutes before closing time. On Tuesday to Saturday, the last appointment therefore starts at 6:30 PM. On Sunday it starts at 7:00 PM.

## Happy Hours
Happy Hours run from Tuesday to Saturday, 11:30 AM to 2:00 PM. During this time, eligible services get a discount. The discount rate and conditions are stated in the current policy document. Happy Hours do not run on Sunday.

## Who Uses This Assistant
This knowledge assistant is for the salon's front-desk team and booking staff. They use it to quickly check prices, opening hours, policy rules, and answers to common client questions, and to see which document each answer comes from.

## Payment
We accept cash and bank transfer. Payment is made at the end of the service, except where a deposit is required by the current policy.
