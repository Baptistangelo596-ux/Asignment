# Glossip Beauty - Client Policy

Policy version: 2.0
Effective date: 1 September 2026
Status: CURRENT
Replaces: Policy version 1.0 (archived)

This is the policy that applies to all bookings made on or after 1 September 2026.

## 1. Booking
- Appointments are made only by phone, WhatsApp, or Instagram direct message.
- A booking is confirmed when our team replies with the date, time, and service.
- For hair colour, keratin, and hair botox, clients must book at least 48 hours in advance.

## 2. Deposit
A deposit of 30% of the service price is required for any single service priced above PKR 8,000. The deposit is paid by bank transfer within 3 hours of confirming the booking. It is deducted from the final bill. Unpaid deposits cancel the booking automatically.

## 3. Cancellation and Rescheduling
- Clients must give at least 24 hours' notice to cancel or reschedule.
- If notice is shorter than 24 hours, the deposit is not refunded.
- If no deposit was paid, a late cancellation fee of PKR 1,000 applies on the next visit.
- A client can reschedule once for free. A second reschedule of the same booking is treated as a cancellation.

## 4. Late Arrival
- We hold an appointment for 15 minutes after the booked time.
- After 15 minutes, we may shorten the service or move the appointment if the schedule allows.
- If we cannot fit the client in, the booking is treated as a late cancellation.

## 5. Happy Hours Discount
- Happy Hours run Tuesday to Saturday, 11:30 AM to 2:00 PM.
- The discount is 20% on single services and blow-dries.
- Happy Hours need an advance appointment. Walk-ins are not accepted.
- The discount cannot be combined with packages or other offers.

## 6. Refunds and Service Satisfaction
- If a client is unhappy with a service, she must tell us before leaving the salon.
- We will offer a free correction within 7 days. Cash refunds are not given for completed services.
- Refunds are made only for deposits on bookings cancelled with proper notice.

## 7. Exceptions
**Exception A: Bridal and event bookings.** Bridal and Shaadi Season bookings need a 50% deposit and at least 7 days' notice to cancel. The general 24-hour rule in section 3 does not apply to them.

**Exception B: Medical or emergency cancellations.** If a client cancels late because of a documented medical emergency, we return the deposit in full. A doctor's note or hospital slip is needed.

## 8. Privacy and Photos
We do not take photos of clients without permission. Client contact details are used only for booking and are never shared.
