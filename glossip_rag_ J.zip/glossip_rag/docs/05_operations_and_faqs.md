# Glossip Beauty - Operations and FAQs

Document type: Operations and FAQs
Last updated: 1 September 2026
Status: CURRENT

## Front-Desk Procedures

### Taking a booking
1. Ask for the client's name, phone number, service, and preferred date and time.
2. Check the service duration in the Services and Prices document.
3. Check that the appointment fits inside opening hours and the last-appointment rule.
4. Reply to confirm the booking, and ask for a deposit if one is required.

### Handling a late cancellation
1. Check the time between the cancellation message and the appointment.
2. Check whether a deposit was paid.
3. Apply the rules in the current policy. Check whether the booking is a bridal booking first, because bridal bookings follow a different rule.

### Patch tests
Before keratin or hair botox, a patch test is done if the client has had colour or chemical treatment in the last 30 days. The patch test is free and takes 15 minutes. Staff must wait 48 hours after the patch test before starting the treatment.

### Hygiene
Tools are sterilised after each client. Wax is never reused. Towels are washed after every use.

## Frequently Asked Questions

**Do you offer services for men?**
No. Glossip Beauty is women-only.

**Can I walk in without an appointment?**
Walk-ins are accepted outside Happy Hours if a chair is free. Walk-ins are not accepted from 11:30 AM to 2:00 PM, Tuesday to Saturday.

**How do I book?**
By phone or WhatsApp on 0300 1234567, or by Instagram direct message. Email is not accepted for bookings.

**What days are you closed?**
We are closed every Monday.

**What time do you open on Sunday?**
12:30 PM. We close at 8:30 PM.

**Do you accept cards?**
We accept cash and bank transfer only.

**Is the Happy Hours discount available on packages?**
No. It applies only to single services and blow-dries.

**How much is the Shaadi Season Refresh Package?**
PKR 9,500. It includes a blow-dry, a hydra peeling facial, and a classic manicure.

**Can I bring a friend or child with me?**
A friend may wait in the reception area. Children under 12 may stay only with a booked adult client, as we do not provide childcare.

**Can I change my booking?**
Yes. You can reschedule once for free with at least 24 hours' notice. Bridal bookings need 7 days' notice.

**How long does a keratin treatment take?**
About 3 hours.

**I am not happy with my service. What can I do?**
Tell us before you leave. We offer a free correction within 7 days.

**Is there any other information I should know before my visit?**
Please arrive 5 to 10 minutes early and tell the stylist about any allergies or skin conditions.
