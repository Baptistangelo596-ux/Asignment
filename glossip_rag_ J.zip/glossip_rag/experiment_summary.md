# Retrieval experiment summary

evidence = required facts retrieved; irrelevant = retrieved chunks from unneeded documents; answer = automatic correctness check.

## chunk_size=500, overlap=100 (34 chunks)

| Test | k=1 | k=3 | k=5 |
|---|---|---|---|
| Q3 | evidence True, irrelevant 0, answer yes | evidence True, irrelevant 1, answer yes | evidence True, irrelevant 3, answer yes |
| Q8 | evidence False, irrelevant 1, answer no | evidence True, irrelevant 2, answer yes | evidence True, irrelevant 4, answer yes |
| Q10 | evidence False, irrelevant 0, answer no | evidence False, irrelevant 1, answer no | evidence False, irrelevant 1, answer no |
| Q13 | evidence True, irrelevant 0, answer yes | evidence True, irrelevant 0, answer yes | evidence True, irrelevant 0, answer yes |
| Q15 | evidence True, irrelevant 0, answer yes | evidence True, irrelevant 0, answer yes | evidence True, irrelevant 0, answer yes |
| Q18 | evidence n/a, irrelevant 1, answer yes | evidence n/a, irrelevant 3, answer yes | evidence n/a, irrelevant 5, answer yes |

## chunk_size=250, overlap=50 (76 chunks)

| Test | k=1 | k=3 | k=5 |
|---|---|---|---|
| Q8 | evidence True, irrelevant 0, answer yes | evidence True, irrelevant 2, answer yes | evidence True, irrelevant 4, answer yes |
| Q10 | evidence False, irrelevant 0, answer no | evidence False, irrelevant 1, answer no | evidence False, irrelevant 1, answer no |
| Q13 | evidence True, irrelevant 0, answer yes | evidence True, irrelevant 0, answer yes | evidence True, irrelevant 0, answer yes |

## chunk_size=1000, overlap=200 (16 chunks)

| Test | k=1 | k=3 | k=5 |
|---|---|---|---|
| Q8 | evidence False, irrelevant 1, answer no | evidence False, irrelevant 3, answer no | evidence True, irrelevant 5, answer no |
| Q10 | evidence False, irrelevant 0, answer no | evidence False, irrelevant 1, answer no | evidence True, irrelevant 1, answer yes |
| Q13 | evidence True, irrelevant 0, answer no | evidence True, irrelevant 0, answer yes | evidence True, irrelevant 0, answer yes |
