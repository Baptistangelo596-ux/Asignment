"""
ingest.py - build the knowledge index for the Glossip Beauty assistant.

Pipeline (assignment steps 1-4):
    1. Load every document in docs/
    2. Split each document into chunks
    3. Generate embeddings (local sentence-transformers model, no API key)
    4. Store chunks + embeddings + metadata in Chroma

Every chunk keeps its filename and its policy version / status in the metadata,
so rag.py can filter on them later.

Usage (from the project folder):
    python ingest.py
    python ingest.py --chunk-size 250 --chunk-overlap 50
"""
import argparse
import hashlib
import json
import re
import time
from pathlib import Path

from langchain_chroma import Chroma
from langchain_community.document_loaders import TextLoader
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

BASE_DIR = Path(__file__).resolve().parent
DOCS_DIR = BASE_DIR / "docs"
PERSIST_DIR = BASE_DIR / "chroma_db"          # generated folder - never put it in the ZIP
COLLECTION_NAME = "glossip_docs"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"   # same model as Module 08
DEFAULT_CHUNK_SIZE = 500                       # same defaults as Module 08
DEFAULT_CHUNK_OVERLAP = 100
MANIFEST_NAME = "index_manifest.json"


# ----------------------------------------------------------------------------
# 1. Load documents (+ read the version / status header of each file)
# ----------------------------------------------------------------------------
def parse_header(text):
    """Read title, version, effective date and status from the top of a document.

    The header is everything before the first '## ' heading. Policy documents carry lines such as
        Policy version: 2.0
        Effective date: 1 September 2026
        Status: CURRENT            (or ARCHIVED)
    Other documents may carry 'Document type:' and 'Last updated:'. A document without a status
    is treated as current.
    """
    match = re.search(r"^##\s", text, flags=re.MULTILINE)
    head = text[:match.start()] if match else text[:600]

    def find(pattern):
        found = re.search(pattern, head, flags=re.IGNORECASE | re.MULTILINE)
        return found.group(1).strip() if found else ""

    return {
        "title": find(r"^#\s+(.+)$") or "",
        "doc_type": find(r"Document type:\s*([^\n]+)"),
        "version": find(r"Policy version:\s*([\d.]+)"),
        "effective_date": find(r"Effective(?: date)?:\s*([^.\n]+)") or find(r"Last updated:\s*([^\n]+)"),
        "status": (find(r"Status:\s*([A-Za-z]+)") or "current").lower(),
    }


def list_document_paths(docs_dir=DOCS_DIR):
    docs_dir = Path(docs_dir)
    return sorted(docs_dir.glob("*.md")) + sorted(docs_dir.glob("*.txt"))


def load_documents(docs_dir=DOCS_DIR):
    """Load all documents with TextLoader (as in Module 08) and attach metadata."""
    paths = list_document_paths(docs_dir)
    if not paths:
        raise FileNotFoundError(f"No .md or .txt documents found in {docs_dir}")
    documents = []
    for path in paths:
        doc = TextLoader(str(path), encoding="utf-8").load()[0]
        text = doc.page_content.lstrip("\ufeff").strip()
        meta = parse_header(text)
        doc.page_content = text
        is_policy = bool(meta["version"]) or "policy" in path.name.lower()
        doc.metadata = {
            "source": path.name,                                   # filename, used in citations
            "title": meta["title"] or path.stem,
            "doc_type": "policy" if is_policy else (meta["doc_type"] or "general").lower().replace(" ", "_"),
            "version": meta["version"] or "n/a",
            "effective_date": meta["effective_date"] or "n/a",
            "status": meta["status"],                              # current / archived
        }
        documents.append(doc)
    return documents


# ----------------------------------------------------------------------------
# 2. Split into chunks
# ----------------------------------------------------------------------------
def split_documents(documents, chunk_size=DEFAULT_CHUNK_SIZE, chunk_overlap=DEFAULT_CHUNK_OVERLAP):
    """Split documents; the splitter copies each document's metadata onto its chunks."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        add_start_index=True,
    )
    chunks = splitter.split_documents(documents)
    counters = {}
    for chunk in chunks:
        name = chunk.metadata["source"]
        counters[name] = counters.get(name, 0) + 1
        chunk.metadata["chunk_id"] = f"{name}#{counters[name]}"   # unique, readable id
    return chunks


# ----------------------------------------------------------------------------
# 3. Embeddings
# ----------------------------------------------------------------------------
def get_embeddings():
    """Local Hugging Face embeddings - the first run downloads the model once."""
    return HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)


# ----------------------------------------------------------------------------
# 4. Store in Chroma (and remember what the index was built from)
# ----------------------------------------------------------------------------
def docs_fingerprint(docs_dir=DOCS_DIR, chunk_size=DEFAULT_CHUNK_SIZE, chunk_overlap=DEFAULT_CHUNK_OVERLAP):
    """A hash of every document + the chunk settings.

    Chroma stores a COPY of each chunk and its vector. Editing a file in docs/ does
    not touch that copy, so we compare this hash with the one saved at build time
    to notice that the index is out of date.
    """
    digest = hashlib.sha256()
    for path in list_document_paths(docs_dir):
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes().replace(b"\r\n", b"\n"))
    digest.update(f"{chunk_size}|{chunk_overlap}|{EMBEDDING_MODEL}".encode("utf-8"))
    return digest.hexdigest()


def read_manifest(persist_dir=PERSIST_DIR):
    path = Path(persist_dir) / MANIFEST_NAME
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def index_status(docs_dir=DOCS_DIR, persist_dir=PERSIST_DIR,
                 chunk_size=DEFAULT_CHUNK_SIZE, chunk_overlap=DEFAULT_CHUNK_OVERLAP):
    """Return 'missing', 'stale' (documents changed after the build) or 'fresh'."""
    manifest = read_manifest(persist_dir)
    if manifest is None:
        return "missing"
    if manifest.get("fingerprint") != docs_fingerprint(docs_dir, chunk_size, chunk_overlap):
        return "stale"
    return "fresh"


def build_index(docs_dir=DOCS_DIR, persist_dir=PERSIST_DIR, collection_name=COLLECTION_NAME,
                chunk_size=DEFAULT_CHUNK_SIZE, chunk_overlap=DEFAULT_CHUNK_OVERLAP,
                embeddings=None):
    """Rebuild the vector database from scratch from the files in docs/.

    persist_dir=None builds a temporary in-memory index (used by experiment.py).
    Returns (vector_db, stats).
    """
    embeddings = embeddings or get_embeddings()
    documents = load_documents(docs_dir)
    chunks = split_documents(documents, chunk_size, chunk_overlap)

    chroma_kwargs = {}
    if persist_dir is not None:
        persist_dir = Path(persist_dir)
        persist_dir.mkdir(parents=True, exist_ok=True)
        chroma_kwargs["persist_directory"] = str(persist_dir)
        # Delete the OLD collection first, so edited or deleted documents can never
        # leave stale chunks behind.
        try:
            Chroma(collection_name=collection_name, embedding_function=embeddings,
                   persist_directory=str(persist_dir)).delete_collection()
        except Exception:
            pass   # nothing to delete on the very first build

    vector_db = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        collection_name=collection_name,
        ids=[chunk.metadata["chunk_id"] for chunk in chunks],
        **chroma_kwargs,
    )

    per_document = {}
    for chunk in chunks:
        per_document[chunk.metadata["source"]] = per_document.get(chunk.metadata["source"], 0) + 1
    stats = {
        "documents": len(documents),
        "chunks": len(chunks),
        "chunks_per_document": per_document,
        "chunk_size": chunk_size,
        "chunk_overlap": chunk_overlap,
        "embedding_model": EMBEDDING_MODEL,
        "built_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "fingerprint": docs_fingerprint(docs_dir, chunk_size, chunk_overlap),
    }
    if persist_dir is not None:
        (persist_dir / MANIFEST_NAME).write_text(json.dumps(stats, indent=2), encoding="utf-8")
    return vector_db, stats


def main():
    parser = argparse.ArgumentParser(description="Rebuild the Glossip knowledge index.")
    parser.add_argument("--chunk-size", type=int, default=DEFAULT_CHUNK_SIZE)
    parser.add_argument("--chunk-overlap", type=int, default=DEFAULT_CHUNK_OVERLAP)
    args = parser.parse_args()

    print(f"Reading documents from {DOCS_DIR} ...")
    _, stats = build_index(chunk_size=args.chunk_size, chunk_overlap=args.chunk_overlap)
    print(f"Indexed {stats['chunks']} chunks from {stats['documents']} documents "
          f"(chunk_size={stats['chunk_size']}, overlap={stats['chunk_overlap']}).")
    for name, count in stats["chunks_per_document"].items():
        print(f"  {name}: {count} chunk(s)")
    print(f"Index saved in {PERSIST_DIR}")


if __name__ == "__main__":
    main()
