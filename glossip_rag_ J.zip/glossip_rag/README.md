# Glossip Beauty Knowledge Assistant

A small RAG (retrieval-augmented generation) application for **Glossip Beauty**, a fictional women-only beauty salon in
Karachi. The front-desk team and booking staff ask questions about services, prices, opening hours, client policy and
procedures. The assistant answers **only from the company documents**, shows the source filename and excerpt, and says
*"I could not find enough information in the provided documents."* when the evidence is missing.

> Classroom prototype (Generative AI, Module 08). All company data is fictional. Not ready for real users, see
> "Before real use" below.

**Demo video (3-5 minutes):** https://drive.google.com/file/d/1WD-OJ35M2BqKTQdb70iddp1GPMaPFWEw/view?usp=sharing

## Installation

Python 3.11 or 3.12 is recommended. Run these commands in a terminal inside the project folder.

```bash
python -m venv venv
venv\Scripts\activate            # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env           # Mac/Linux: cp .env.example .env
```

Open `.env` and replace the placeholder with your own key (`GROQ_API_KEY`, or set `LLM_PROVIDER=gemini` and add
`GOOGLE_API_KEY`). Never share or submit `.env`.

## Run the application

```bash
python -m streamlit run app.py
```

On the first run the app builds the Chroma index from the files in `docs/` (the embedding model, about 90 MB, is
downloaded once). The index is stored in the generated `chroma_db/` folder. It is rebuilt from the documents at any
time, so it is not part of the submission.

## Other commands

| Command | Purpose |
|---|---|
| `python ingest.py` | Rebuild the index from `docs/` (options: `--chunk-size 250 --chunk-overlap 50`) |
| `python run_tests.py` | Run the 20 tests in `tests.csv` and write `test_results.csv` (add `--k 5` or `--delay 6` if needed) |
| `python experiment.py` | k = 1, 3, 5 comparison and chunk-size comparison, writes `experiment_results.csv` and `experiment_summary.md` (add `--retrieval-only` to skip the LLM) |

## Files

```
docs/                          the knowledge base (6 documents; version, effective date and status in each header)
  01_company_overview.md       services, opening hours, location, contact details
  02_services_and_prices.md    26 services and 1 package with prices and durations
  03_current_policy_v2.md      client policy version 2.0, CURRENT, effective 1 September 2026
  04_previous_policy_v1_archived.md   client policy version 1.0, ARCHIVED (replaced on 1 September 2026)
  05_operations_and_faqs.md    front-desk procedures and FAQs
  06_test_notice_board.md      untrusted notice-board text that contains the prompt-injection test sentences
ingest.py                      load -> chunk -> embed -> store in Chroma (keeps filename, version, status per chunk)
rag.py                         policy-version rule, retrieval, prompt, LLM call, citations
app.py                         Streamlit interface
evaluation.py                  automatic first-pass checker used by run_tests.py and experiment.py
tests.csv                      the 20 questions with expected answers and sources (written before the final run)
run_tests.py, experiment.py
```

## How the policy versions work

Every document starts with a header (for the policies: `Policy version`, `Effective date`, `Status: CURRENT` or
`ARCHIVED`). `ingest.py` copies these into the metadata of every chunk. `rag.py` then applies one coded rule
(`detect_policy_mode`):

* a normal question searches only chunks with `status = current`;
* a question about old rules (*old, previous, archived ...*) searches only `status = archived`;
* a question that compares old and new rules searches the current **and** the archived policy (k/2 chunks each).

The source label given to the LLM includes version and status, and the prompt forbids presenting an archived rule
as the current one. The rule is keyword based, so an unusual phrasing can be misclassified.

## Final live challenge: changing one policy rule

1. Edit the rule in `docs/03_current_policy_v2.md` (for example the deposit percentage or the cancellation notice).
2. Rebuild the index: `python ingest.py`, or click **Rebuild index** in the app sidebar.
3. Ask the question again; the answer now follows the new rule.

**Why editing the file alone is not enough:** Chroma stores its own copy of every chunk and its vector, created when the
index was built. The `.md` file is only read during that build, so the app keeps answering from the old stored chunks
until the index is rebuilt. The app stores a hash of the documents at build time and shows a warning when the files in
`docs/` no longer match the index.

## Before real use

This is a classroom prototype. A company would still need: verified documents with a named owner and an approval
process for changes; automatic re-indexing when documents change; login and access control, and no personal data in
the knowledge base; a much larger test set with human review and regular re-testing; logging and monitoring of wrong
or refused answers; a relevance threshold and a human fallback for important decisions such as deposits and refunds;
stronger defences against prompt injection than prompt wording alone; and a plan for hosting, cost, rate limits and
uptime (this version relies on a free-tier LLM API).
