"""
experiment.py - retrieval investigation (assignment step 5).

Part A: six questions x k = 1, 3, 5 with the baseline chunking (documents, chunk size
        and questions stay unchanged while k changes).
Part B: change the chunk size / overlap and repeat three of the questions.

For each question and k it records:
    * evidence_retrieved  - were all the required facts (evidence_terms in tests.csv) in the retrieved text?
    * irrelevant_chunks   - how many retrieved chunks came from a document the question does not need?
    * answer_correct      - automatic check of the final answer (read the answers yourself too!)

Usage:
    python experiment.py                    # full run with the LLM (about 36 LLM calls)
    python experiment.py --retrieval-only   # no LLM: only the retrieval columns
Output: experiment_results.csv and experiment_summary.md
"""
import argparse
import time

import pandas as pd

from evaluation import grade, split_list, terms_present
from ingest import BASE_DIR, build_index, get_embeddings
from rag import ask_rag

TESTS_FILE = BASE_DIR / "tests.csv"

SIX_QUESTIONS = [3, 8, 10, 13, 15, 18]      # test ids used for the k comparison
CHUNK_QUESTIONS = [8, 10, 13]               # three of them, repeated with other chunk settings
K_VALUES = [1, 3, 5]
BASELINE = (500, 100)                        # chunk_size, chunk_overlap (same as Module 08)
VARIANTS = [(250, 50), (1000, 200)]


def run_config(embeddings, tests, chunk_size, chunk_overlap, question_ids, args):
    vector_db, stats = build_index(persist_dir=None, collection_name=f"exp_{chunk_size}_{chunk_overlap}",
                                   chunk_size=chunk_size, chunk_overlap=chunk_overlap, embeddings=embeddings)
    print(f"\n=== chunk_size={chunk_size}, overlap={chunk_overlap}: {stats['chunks']} chunks ===")
    rows = []
    for qid in question_ids:
        test = tests[str(qid)]
        needed = split_list(test["expected_sources"])
        for k in K_VALUES:
            result = ask_rag(test["question"], k=k, vector_db=vector_db, generate=not args.retrieval_only)
            retrieved = [s["source"] for s in result["sources"]]
            retrieved_text = "\n".join(s["text"] for s in result["sources"])
            if test["evidence_terms"]:
                evidence_ok, _ = terms_present(retrieved_text, test["evidence_terms"])
                irrelevant = sum(1 for name in retrieved if name not in needed)
            else:                                    # unanswerable question: nothing is "required"
                evidence_ok, irrelevant = "n/a", len(retrieved)
            if args.retrieval_only:
                correct, reason = "not run", ""
            else:
                verdict, reason = grade(test, result["answer"], result["cited"], retrieved, result["error"])
                correct = "yes" if verdict == "PASS" else "no"
                time.sleep(args.delay)
            rows.append({
                "chunk_size": chunk_size, "chunk_overlap": chunk_overlap, "n_chunks": stats["chunks"],
                "test_id": qid, "question": test["question"], "k": k,
                "policy_mode": result["mode"],
                "evidence_retrieved": evidence_ok,
                "irrelevant_chunks": irrelevant,
                "retrieved_sources": "; ".join(retrieved),
                "answer_correct": correct,
                "reason": reason,
                "answer": result["answer"],
            })
            print(f"  Q{qid} k={k}: evidence={evidence_ok} irrelevant={irrelevant} answer={correct}")
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--retrieval-only", action="store_true", help="skip the LLM")
    parser.add_argument("--delay", type=float, default=2.0)
    args = parser.parse_args()

    table = pd.read_csv(TESTS_FILE, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    tests = {row["id"]: row.to_dict() for _, row in table.iterrows()}
    embeddings = get_embeddings()

    rows = run_config(embeddings, tests, *BASELINE, SIX_QUESTIONS, args)
    for size, overlap in VARIANTS:
        rows += run_config(embeddings, tests, size, overlap, CHUNK_QUESTIONS, args)

    results = pd.DataFrame(rows)
    results.to_csv(BASE_DIR / "experiment_results.csv", index=False, encoding="utf-8-sig")

    summary = ["# Retrieval experiment summary", "",
               "evidence = required facts retrieved; irrelevant = retrieved chunks from unneeded documents; "
               "answer = automatic correctness check.", ""]
    for (size, overlap), group in results.groupby(["chunk_size", "chunk_overlap"], sort=False):
        summary += [f"## chunk_size={size}, overlap={overlap} ({group['n_chunks'].iloc[0]} chunks)", "",
                    "| Test | k=1 | k=3 | k=5 |", "|---|---|---|---|"]
        for qid, rows_q in group.groupby("test_id", sort=False):
            cells = []
            for k in K_VALUES:
                r = rows_q[rows_q["k"] == k].iloc[0]
                cells.append(f"evidence {r['evidence_retrieved']}, irrelevant {r['irrelevant_chunks']}, "
                             f"answer {r['answer_correct']}")
            summary.append(f"| Q{qid} | " + " | ".join(cells) + " |")
        summary.append("")
    (BASE_DIR / "experiment_summary.md").write_text("\n".join(summary), encoding="utf-8")
    print("\nSaved experiment_results.csv and experiment_summary.md")


if __name__ == "__main__":
    main()
